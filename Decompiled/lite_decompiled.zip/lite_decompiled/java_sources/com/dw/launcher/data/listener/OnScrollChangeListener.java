package com.dw.launcher.data.listener;

import cn.carbswang.android.numberpickerview.library.BuildConfig;
import kotlin.Metadata;

/* JADX INFO: compiled from: OnScrollChangeListener.kt */
/* JADX INFO: loaded from: /home/runner/work/Launcher-Decompiled/Launcher-Decompiled/extracted_dex/DwNewLauncher3_classes.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&¨\u0006\u0006"}, d2 = {"Lcom/dw/launcher/data/listener/OnScrollChangeListener;", BuildConfig.FLAVOR, "onScrollChange", BuildConfig.FLAVOR, "scrollToEnd", BuildConfig.FLAVOR, "app_version8Release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface OnScrollChangeListener {
    void onScrollChange(boolean scrollToEnd);
}
