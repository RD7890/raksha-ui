package com.raksha.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.ImageView
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.BatteryManager
import android.widget.TextClock
import android.widget.FrameLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.gif.GifDrawable
import com.bumptech.glide.request.target.ImageViewTarget
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.raksha.ui.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private val dateFormat = SimpleDateFormat("EEE   MM/dd", Locale.getDefault())

    private val wallpaperFile by lazy { File(filesDir, "custom_wallpaper.jpg") }
    private var allAppsList: List<AppInfo> = emptyList()
    
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<View>
    private lateinit var gestureDetector: GestureDetector
    private lateinit var soundManager: SoundManager

    private val appUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action
            if (action == Intent.ACTION_PACKAGE_ADDED ||
                action == Intent.ACTION_PACKAGE_REMOVED ||
                action == Intent.ACTION_PACKAGE_REPLACED) {
                loadAppsOptimized()
            }
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_POWER_CONNECTED) {
                soundManager.playChargeSound()
                val chargeIntent = Intent(context, ChargeActivity::class.java)
                chargeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(chargeIntent)
            }
        }
    }

    private val updateTimeTask = object : Runnable {
        override fun run() {
            val now = Date()
            val timeFmt = android.text.format.DateFormat.getTimeFormat(this@MainActivity)
            binding.tvClock.text = timeFmt.format(now)
            binding.tvDate.text = dateFormat.format(now).uppercase()
            handler.postDelayed(this, 1000)
        }
    }

    private val pickWallpaperLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data?.data != null) {
            val uri = result.data!!.data!!
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(wallpaperFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    loadWallpaper()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        soundManager = SoundManager(this)

        loadWallpaper()
        setupBottomSheetAndGestures()
        loadAppsOptimized()

        if (savedInstanceState == null) {
            showBootAnimation()
        }
    }

    private fun loadWallpaper() {
        lifecycleScope.launch(Dispatchers.IO) {
            if (wallpaperFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(wallpaperFile.absolutePath)
                withContext(Dispatchers.Main) {
                    binding.ivWallpaper.setImageBitmap(bitmap)
                    binding.tvHint.visibility = View.GONE
                }
            } else {
                withContext(Dispatchers.Main) {
                    binding.tvHint.visibility = View.VISIBLE
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(Intent.ACTION_POWER_CONNECTED)
        registerReceiver(batteryReceiver, filter)
        
        val packageFilter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(appUpdateReceiver, packageFilter)
        
        handler.post(updateTimeTask)
        binding.rvApps.requestFocus()
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(batteryReceiver)
            unregisterReceiver(appUpdateReceiver)
        } catch (e: Exception) {}
        handler.removeCallbacks(updateTimeTask)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupBottomSheetAndGestures() {
        val bottomSheetBehavior = BottomSheetBehavior.from(binding.rvApps)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
        bottomSheetBehavior.peekHeight = 0
        bottomSheetBehavior.isHideable = true
        bottomSheetBehavior.skipCollapsed = true

        bottomSheetBehavior.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                    binding.rvApps.requestFocus()
                }
            }

            override fun onSlide(bottomSheet: View, slideOffset: Float) {
                binding.homeScreen.alpha = 1f - slideOffset
                // dim overlay grows to 0.3 alpha as drawer opens
                binding.vDimOverlay.alpha = slideOffset * 0.3f
            }
        })
        
        binding.rvApps.layoutManager = LinearLayoutManager(this)

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 != null && e2 != null) {
                    val diffY = e1.y - e2.y
                    // Swipe up
                    if (diffY > 50 && Math.abs(velocityY) > 100) {
                        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
                        return true
                    }
                }
                return false
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (distanceY > 10) {
                    bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
                    return true
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                val intent = Intent(Intent.ACTION_PICK)
                intent.type = "image/*"
                pickWallpaperLauncher.launch(intent)
            }
        })

        binding.homeScreen.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }

        binding.btnAppDrawer.setOnClickListener {
            binding.rvApps.adapter = AppAdapter(allAppsList) { app ->
                launchApp(app.packageName)
            }
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        }

    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun loadAppsOptimized() {
        val lm = LinearLayoutManager(this)
        lm.isItemPrefetchEnabled = true
        binding.rvApps.layoutManager = lm
        binding.rvApps.setHasFixedSize(true)
        binding.rvApps.setItemViewCacheSize(30)
        binding.rvApps.isNestedScrollingEnabled = true   // MUST be true for BottomSheet scroll to work correctly
        binding.rvApps.overScrollMode = View.OVER_SCROLL_NEVER

        lifecycleScope.launch(Dispatchers.Default) {
            val intent = Intent(Intent.ACTION_MAIN, null)
            intent.addCategory(Intent.CATEGORY_LAUNCHER)

            val apps = packageManager.queryIntentActivities(intent, 0)
            allAppsList = apps.mapNotNull { info ->
                try {
                    AppInfo(
                        name = info.loadLabel(packageManager),
                        packageName = info.activityInfo.packageName,
                        icon = info.activityInfo.loadIcon(packageManager)
                    )
                } catch (e: Exception) {
                    null
                }
            }.sortedBy { it.name.toString() }

            withContext(Dispatchers.Main) {
                binding.rvApps.adapter = AppAdapter(allAppsList) { app ->
                    launchApp(app.packageName)
                }
            }
        }
    }

    private fun showBootAnimation() {
        val overlay = findViewById<FrameLayout>(R.id.bootAnimationOverlay)
        val img = findViewById<ImageView>(R.id.bootAnimationImage)
        overlay.visibility = View.VISIBLE
        
        Glide.with(this)
            .asGif()
            .load(R.drawable.boot_animation)
            .into(object : ImageViewTarget<GifDrawable>(img) {
                override fun setResource(resource: GifDrawable?) {
                    img.setImageDrawable(resource)
                    resource?.setColorFilter(android.graphics.Color.parseColor("#ff99cc"), android.graphics.PorterDuff.Mode.SRC_ATOP)
                }
            })
            
        handler.postDelayed({
            overlay.animate().alpha(0f).setDuration(500).withEndAction {
                overlay.visibility = View.GONE
            }.start()
        }, 2000)
    }

    private fun launchApp(packageName: String) {
        soundManager.playDingSound()
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val behavior = BottomSheetBehavior.from(binding.rvApps)
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                if (behavior.state != BottomSheetBehavior.STATE_EXPANDED) {
                    behavior.state = BottomSheetBehavior.STATE_EXPANDED
                } else {
                    binding.rvApps.smoothScrollBy(0, -120)
                }
                true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (behavior.state != BottomSheetBehavior.STATE_EXPANDED) {
                    behavior.state = BottomSheetBehavior.STATE_EXPANDED
                } else {
                    binding.rvApps.smoothScrollBy(0, 120)
                }
                true
            }
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER -> {
                if (behavior.state != BottomSheetBehavior.STATE_EXPANDED) {
                    behavior.state = BottomSheetBehavior.STATE_EXPANDED
                    true
                } else {
                    super.onKeyDown(keyCode, event)
                }
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onBackPressed() {
        val behavior = BottomSheetBehavior.from(binding.rvApps)
        if (behavior.state == BottomSheetBehavior.STATE_EXPANDED) {
            behavior.state = BottomSheetBehavior.STATE_HIDDEN
            binding.vDimOverlay.animate().cancel()
            binding.vDimOverlay.alpha = 0f
        } else {
            super.onBackPressed()
        }
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_SCROLL) {
            val vScroll = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
            if (vScroll != 0f) {
                val behavior = BottomSheetBehavior.from(binding.rvApps)
                if (behavior.state != BottomSheetBehavior.STATE_EXPANDED) {
                    behavior.state = BottomSheetBehavior.STATE_EXPANDED
                } else {
                    binding.rvApps.scrollBy(0, (-vScroll * 60).toInt())
                }
                return true
            }
        }
        return super.dispatchGenericMotionEvent(event)
    }
}
